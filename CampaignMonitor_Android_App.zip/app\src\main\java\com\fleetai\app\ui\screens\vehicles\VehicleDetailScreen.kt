package com.fleetai.app.ui.screens.vehicles

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fleetai.app.data.models.*
import com.fleetai.app.data.remote.RetrofitClient
import com.fleetai.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehicleDetailScreen(
    plateNumber: String,
    onNavigateBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var vehicle by remember { mutableStateOf<Vehicle?>(null) }
    var trips by remember { mutableStateOf<List<Trip>>(emptyList()) }
    var maintenance by remember { mutableStateOf<List<MaintenanceLog>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var snackbarMessage by remember { mutableStateOf<String?>(null) }

    fun loadVehicle() {
        coroutineScope.launch {
            isLoading = true
            try {
                val res = RetrofitClient.apiService.getVehicleDetail(plateNumber)
                if (res.isSuccessful && res.body()?.success == true) {
                    val body = res.body()!!
                    vehicle = body.vehicle
                    trips = body.trips
                    maintenance = body.maintenance
                }
            } catch (_: Exception) {}
            isLoading = false
        }
    }

    LaunchedEffect(plateNumber) {
        loadVehicle()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("سجل سيارة: $plateNumber", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface, titleContentColor = TextPrimary)
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        if (isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = PrimaryLightBlue)
            }
        } else if (vehicle == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("لم يتم العثور على بيانات هذه السيارة.", color = TextSecondary)
            }
        } else {
            Column(Modifier.fillMaxSize().padding(padding)) {
                // Header Card: Vehicle Snapshot
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("رقم اللوحة: ${vehicle!!.plateNumber}", color = PrimaryLightBlue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Badge(containerColor = if (vehicle!!.status == "في الطريق") AccentGreen else PrimaryBlue) {
                                Text(vehicle!!.status, color = TextPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("⏱️ قراءة العداد الحالية: ${vehicle!!.currentKm.toLocaleString()} كم", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text("👤 آخر سائق قادها: ${vehicle!!.lastDriver ?: "غير مسجل"}", color = TextSecondary, fontSize = 14.sp)
                    }
                }

                // Tabs: Trips vs Maintenance
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = DarkSurface,
                    contentColor = PrimaryLightBlue
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("سجل الحركات والرحلات (${trips.size})") }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("سجل الصيانة والأعطال (${maintenance.size})") }
                    )
                }

                // Tab Content
                if (selectedTab == 0) {
                    if (trips.isEmpty()) {
                        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                            Text("لا توجد رحلات مسجلة لهذه السيارة حتى الآن.", color = TextSecondary)
                        }
                    } else {
                        LazyColumn(
                            Modifier.fillMaxSize().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(trips) { t ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(t.eventType, color = if (t.eventType.contains("خروج")) AccentOrange else AccentGreen, fontWeight = FontWeight.Bold)
                                            Text(t.createdAt, color = TextSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
                                        }
                                        Spacer(Modifier.height(4.dp))
                                        Text("العداد: ${t.odometerReading?.let { "$it كم" } ?: "غير مسجل"} | السائق: ${t.driverName ?: "غير محدد"}", color = TextPrimary, fontSize = 13.sp)
                                        if (!t.destination.isNullOrBlank()) {
                                            Text("الوجهة: ${t.destination}", color = TextSecondary, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (maintenance.isEmpty()) {
                        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                            Text("سجل الصيانة نظيف. لا توجد بلاغات أعطال مسجلة.", color = AccentGreen)
                        }
                    } else {
                        LazyColumn(
                            Modifier.fillMaxSize().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(maintenance) { m ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = if (m.status == "تم الإصلاح") "✅ تم الإصلاح" else "⚠️ ${m.status}",
                                                color = if (m.status == "تم الإصلاح") AccentGreen else AccentOrange,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(m.reportedAt, color = TextSecondary.copy(alpha = 0.7f), fontSize = 11.sp)
                                        }
                                        Spacer(Modifier.height(6.dp))
                                        Text(m.issueDescription, color = TextPrimary, fontSize = 14.sp)
                                        Spacer(Modifier.height(6.dp))

                                        if (m.status != "تم الإصلاح") {
                                            Button(
                                                onClick = {
                                                    coroutineScope.launch {
                                                        try {
                                                            RetrofitClient.apiService.resolveMaintenance(m.id)
                                                            loadVehicle()
                                                        } catch (_: Exception) {}
                                                    }
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = AccentGreen),
                                                modifier = Modifier.align(Alignment.End)
                                            ) {
                                                Text("تحديد كـ تم الإصلاح", fontSize = 12.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
