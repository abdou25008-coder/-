package com.fleetai.app.ui.screens.fuel

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fleetai.app.data.models.*
import com.fleetai.app.data.remote.RetrofitClient
import com.fleetai.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FuelAndOilScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Oil Radar, 1 = Fuel Analytics
    var oilRadarList by remember { mutableStateOf<List<OilRadarItem>>(emptyList()) }
    var fuelAnalytics by remember { mutableStateOf<FuelAnalyticsData?>(null) }
    var isLoading by remember { mutableStateOf(true) }

    // Oil Change Dialog State
    var showOilDialog by remember { mutableStateOf(false) }
    var selectedPlateForOil by remember { mutableStateOf("") }
    var oilOdoInput by remember { mutableStateOf("") }
    var oilIntervalInput by remember { mutableStateOf("5000") }

    fun loadData() {
        coroutineScope.launch {
            isLoading = true
            try {
                // Fetch Oil Radar
                val oilRes = RetrofitClient.apiService.getOilRadar()
                if (oilRes.isSuccessful && oilRes.body()?.success == true) {
                    oilRadarList = oilRes.body()!!.radar
                }
                // Fetch Fuel Analytics
                val fuelRes = RetrofitClient.apiService.getFuelAnalytics()
                if (fuelRes.isSuccessful && fuelRes.body()?.success == true) {
                    fuelAnalytics = fuelRes.body()!!.data
                }
            } catch (_: Exception) {}
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("إدارة الوقود والصيانة الدورية للزيوت", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface, titleContentColor = TextPrimary),
                actions = {
                    IconButton(onClick = { loadData() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = TextPrimary)
                    }
                }
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            // Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = PrimaryLightBlue
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("رادار الزيوت والصيانة (${oilRadarList.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("تحليلات استهلاك الوقود") }
                )
            }

            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryLightBlue)
                }
            } else if (selectedTab == 0) {
                // --- Tab 1: Oil Radar ---
                LazyColumn(
                    Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = PrimaryLightBlue)
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    "يتم احتساب مواعيد غيار الزيت تلقائياً من قراءات عدادات السيارات الواردة من جروب واتساب.",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    if (oilRadarList.isEmpty()) {
                        item {
                            Text("لا توجد سيارات مسجلة بالرادار.", color = TextSecondary)
                        }
                    } else {
                        items(oilRadarList) { item ->
                            val (badgeColor, icon) = when (item.urgency) {
                                "danger" -> AccentRed to Icons.Default.Warning
                                "warning" -> AccentOrange to Icons.Default.PriorityHigh
                                else -> AccentGreen to Icons.Default.CheckCircle
                            }

                            Card(
                                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(16.dp)) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("🚗 سيارة [${item.plateNumber}]", color = PrimaryLightBlue, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = badgeColor.copy(alpha = 0.2f),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor)
                                        ) {
                                            Row(Modifier.padding(horizontal = 10.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                                Icon(icon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text(item.statusText, color = badgeColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                            }
                                        }
                                    }

                                    Spacer(Modifier.height(8.dp))
                                    HorizontalDivider(color = DividerColor)
                                    Spacer(Modifier.height(8.dp))

                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("⏱️ العداد الحالي: ${item.currentKm.toLocaleString()} كم", color = TextPrimary, fontSize = 13.sp)
                                        Text("آخر غيار: ${item.lastOilKm.toLocaleString()} كم", color = TextSecondary, fontSize = 13.sp)
                                    }

                                    Spacer(Modifier.height(4.dp))
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("الموعد القادم: ${item.nextDueKm.toLocaleString()} كم (دورة ${item.oilIntervalKm} كم)", color = TextSecondary, fontSize = 12.sp)
                                        Text("السائق: ${item.lastDriver ?: "غير محدد"}", color = TextSecondary, fontSize = 12.sp)
                                    }

                                    Spacer(Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            selectedPlateForOil = item.plateNumber
                                            oilOdoInput = "${item.currentKm}"
                                            oilIntervalInput = "${item.oilIntervalKm}"
                                            showOilDialog = true
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                        modifier = Modifier.align(Alignment.End)
                                    ) {
                                        Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("توثيق غيار زيت جديد", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // --- Tab 2: Fuel Analytics ---
                LazyColumn(
                    Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    fuelAnalytics?.summary?.let { s ->
                        item {
                            // Fuel Summary Grid
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("معدل الاستهلاك", color = TextSecondary, fontSize = 11.sp)
                                        Text("${s.avgKmPerLiter} كم/لتر", color = AccentGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("إجمالي اللترات", color = TextSecondary, fontSize = 11.sp)
                                        Text("${s.totalLiters} لتر", color = PrimaryLightBlue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("إجمالي التكلفة", color = TextSecondary, fontSize = 11.sp)
                                        Text("${s.totalCost} ج.م", color = PrimaryBlue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("تنبيهات الهدر", color = TextSecondary, fontSize = 11.sp)
                                        Text("${s.abnormalIncidents}", color = if (s.abnormalIncidents > 0) AccentRed else AccentGreen, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    // Abnormal Incidents
                    fuelAnalytics?.abnormalLogs?.let { abnormal ->
                        if (abnormal.isNotEmpty()) {
                            item {
                                Text("🚨 حالات استهلاك مرتفع وغير طبيعي", color = AccentRed, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            items(abnormal) { a ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = AccentRed)
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            Text("سيارة: ${a.vehiclePlate} (معدل: ${a.fuelRate} كم/لتر)", color = TextPrimary, fontWeight = FontWeight.Bold)
                                            Text("تموين ${a.liters} لتر لمسافة ${a.distanceTraveled} كم فقط. السائق: ${a.driverName ?: "غير محدد"}", color = TextSecondary, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Recent Fuel Logs
                    item {
                        Text("📋 سجلات تموين الوقود الأخيرة", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    fuelAnalytics?.recentLogs?.let { logs ->
                        if (logs.isEmpty()) {
                            item { Text("لا توجد فواتير وقود مسجلة مؤخراً.", color = TextSecondary) }
                        } else {
                            items(logs) { log ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("⛽ سيارة [${log.vehiclePlate}]", color = PrimaryLightBlue, fontWeight = FontWeight.Bold)
                                            Text("${log.liters} لتر (${log.cost} ج.م)", color = AccentGreen, fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(Modifier.height(4.dp))
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text("العداد: ${log.odometerReading?.toLocaleString() ?: "—"} كم", color = TextSecondary, fontSize = 12.sp)
                                            Text("المعدل: ${if (log.fuelRate > 0) "${log.fuelRate} كم/لتر" else "أول تفويلة"}", color = TextPrimary, fontSize = 12.sp)
                                        }
                                        Text("السائق: ${log.driverName ?: "غير محدد"} | ${log.createdAt}", color = TextSecondary.copy(alpha = 0.6f), fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Oil Change Record Dialog
    if (showOilDialog) {
        AlertDialog(
            onDismissRequest = { showOilDialog = false },
            title = { Text("توثيق غيار زيت للسيارة [$selectedPlateForOil]") },
            text = {
                Column {
                    Text("أدخل قراءة عداد السيارة وقت تغيير الزيت:", fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = oilOdoInput,
                        onValueChange = { oilOdoInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("دورة الزيت بالكيلومتر (5000 أو 10000):", fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = oilIntervalInput,
                        onValueChange = { oilIntervalInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                val odo = oilOdoInput.toLongOrNull()
                                val interval = oilIntervalInput.toLongOrNull()
                                val res = RetrofitClient.apiService.recordOilChange(
                                    RecordOilChangeRequest(selectedPlateForOil, odo, interval)
                                )
                                if (res.isSuccessful && res.body()?.success == true) {
                                    Toast.makeText(context, "تم حفظ غيار الزيت وتصفير العداد!", Toast.LENGTH_SHORT).show()
                                    showOilDialog = false
                                    loadData()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "خطأ: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
                ) {
                    Text("حفظ وتأكيد")
                }
            },
            dismissButton = {
                TextButton(onClick = { showOilDialog = false }) { Text("إلغاء") }
            }
        )
    }
}
