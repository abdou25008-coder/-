package com.fleetai.app.ui.screens.drivers

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fleetai.app.data.models.Driver
import com.fleetai.app.data.remote.RetrofitClient
import com.fleetai.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DriversScreen(
    onNavigateToDriverDetail: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var drivers by remember { mutableStateOf<List<Driver>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }

    fun loadDrivers() {
        coroutineScope.launch {
            isLoading = true
            try {
                val res = RetrofitClient.apiService.getDrivers()
                if (res.isSuccessful && res.body()?.success == true) {
                    drivers = res.body()!!.drivers
                }
            } catch (_: Exception) {}
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadDrivers()
    }

    val filtered = drivers.filter {
        it.name.contains(searchQuery.trim(), ignoreCase = true) ||
        (it.currentVehicle?.contains(searchQuery.trim(), ignoreCase = true) == true)
    }

    val activeTodayCount = drivers.count { it.activeToday == 1 }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الموارد البشرية ونشاط السائقين", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface, titleContentColor = TextPrimary),
                actions = {
                    IconButton(onClick = { loadDrivers() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = TextPrimary)
                    }
                }
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // HR Snapshot Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("متابعة الحضور الميداني اليوم", color = TextSecondary, fontSize = 12.sp)
                        Text(
                            "$activeTodayCount سائق مسجل اليوم من أصل ${drivers.size}",
                            color = AccentGreen,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Badge(containerColor = PrimaryBlue) {
                        Text("مدير الموارد البشرية", color = TextPrimary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Search Box
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ابحث باسم السائق أو السيارة الحالية...", color = TextSecondary) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryLightBlue,
                    unfocusedBorderColor = DividerColor,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(Modifier.height(14.dp))

            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryLightBlue)
                }
            } else if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا يوجد سائقين مسجلين حالياً.", color = TextSecondary)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(filtered) { d ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToDriverDetail(d.name) }
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (d.activeToday == 1) AccentGreen.copy(alpha = 0.2f) else DarkCard,
                                            modifier = Modifier.size(42.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    Icons.Default.Person,
                                                    contentDescription = null,
                                                    tint = if (d.activeToday == 1) AccentGreen else TextSecondary,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                        }
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            Text(d.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            Text(
                                                if (d.activeToday == 1) "🟢 نشط بالعمل اليوم" else "⚪ لم يسجل حركة اليوم",
                                                color = if (d.activeToday == 1) AccentGreen else TextSecondary,
                                                fontSize = 12.sp
                                            )
                                        }
                                    }

                                    // Monthly Working Days Badge
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = PrimaryBlue.copy(alpha = 0.2f),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, PrimaryLightBlue)
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text("أيام العمل هذا الشهر", color = TextSecondary, fontSize = 10.sp)
                                            Text("${d.workingDaysThisMonth} يوم", color = PrimaryLightBlue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        }
                                    }
                                }

                                Spacer(Modifier.height(10.dp))
                                HorizontalDivider(color = DividerColor)
                                Spacer(Modifier.height(8.dp))

                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("🚗 السيارة الحالية: ${d.currentVehicle ?: "غير محدد"}", color = TextPrimary, fontSize = 13.sp)
                                    Text("🔢 رحلات الشهر: ${d.tripsThisMonth}", color = TextSecondary, fontSize = 13.sp)
                                }

                                if (!d.lastActive.isNullOrBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text("🕒 آخر ظهور: ${d.lastActive}", color = TextSecondary.copy(alpha = 0.6f), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
