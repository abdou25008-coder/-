package com.fleetai.app

import android.app.Application

class FleetApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
