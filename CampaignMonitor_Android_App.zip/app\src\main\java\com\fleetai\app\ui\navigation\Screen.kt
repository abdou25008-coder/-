package com.fleetai.app.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Dashboard : Screen("dashboard", "الرئيسية")
    object Vehicles : Screen("vehicles", "السيارات")
    object VehicleDetail : Screen("vehicle_detail/{plate}", "سجل السيارة") {
        fun createRoute(plate: String) = "vehicle_detail/$plate"
    }
    object Drivers : Screen("drivers", "السائقين")
    object DriverDetail : Screen("driver_detail/{name}", "سجل السائق والموارد البشرية") {
        fun createRoute(name: String) = "driver_detail/$name"
    }
    object FuelAndOil : Screen("fuel_and_oil", "الوقود والزيوت")
    object WhatsApp : Screen("whatsapp", "إدارة واتساب")
    object Reports : Screen("reports", "التقارير")
}
