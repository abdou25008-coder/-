package com.fleetai.app.data.remote

import com.fleetai.app.data.models.*
import retrofit2.Response
import retrofit2.http.*

interface FleetApiService {

    @GET("api/dashboard")
    suspend fun getDashboard(): Response<DashboardResponse>

    @GET("api/vehicles")
    suspend fun getVehicles(): Response<VehiclesResponse>

    @GET("api/vehicles/{plate}")
    suspend fun getVehicleDetail(@Path("plate") plate: String): Response<VehicleDetailResponse>

    @GET("api/drivers")
    suspend fun getDrivers(@Query("month") month: String? = null): Response<DriversResponse>

    @GET("api/drivers/{name}/monthly")
    suspend fun getDriverMonthlyActivity(
        @Path("name") name: String,
        @Query("month") month: String? = null
    ): Response<DriverMonthlyResponse>

    @GET("api/whatsapp/status")
    suspend fun getWhatsAppStatus(): Response<WhatsAppStatusResponse>

    @GET("api/groups")
    suspend fun getGroups(): Response<GroupsResponse>

    @POST("api/groups/toggle")
    suspend fun toggleGroup(@Body request: GroupToggleRequest): Response<SimpleResponse>

    @POST("api/groups/settings")
    suspend fun updateGroupSettings(@Body request: GroupSettingsRequest): Response<SimpleResponse>

    @GET("api/fuel/analytics")
    suspend fun getFuelAnalytics(): Response<FuelAnalyticsResponse>

    @GET("api/oil/radar")
    suspend fun getOilRadar(): Response<OilRadarResponse>

    @POST("api/oil/record")
    suspend fun recordOilChange(@Body request: RecordOilChangeRequest): Response<SimpleResponse>

    @POST("api/reports/generate")
    suspend fun generateReport(@Body request: ReportRequest): Response<ReportResponse>

    @POST("api/reports/send-whatsapp")
    suspend fun sendReportViaWhatsApp(@Body request: SendWhatsAppRequest): Response<SimpleResponse>

    @POST("api/maintenance/{id}/resolve")
    suspend fun resolveMaintenance(@Path("id") id: Long): Response<SimpleResponse>
}
