package com.fleetai.app.ui.screens.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fleetai.app.data.models.*
import com.fleetai.app.data.remote.RetrofitClient
import com.fleetai.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onNavigateToVehicleDetail: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var stats by remember { mutableStateOf<DashboardStats?>(null) }
    var recentTrips by remember { mutableStateOf<List<Trip>>(emptyList()) }
    var pendingMaintenance by remember { mutableStateOf<List<MaintenanceLog>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun loadData() {
        coroutineScope.launch {
            isLoading = true
            errorMessage = null
            try {
                val res = RetrofitClient.apiService.getDashboard()
                if (res.isSuccessful && res.body()?.success == true) {
                    val body = res.body()!!
                    stats = body.stats
                    recentTrips = body.recentTrips
                    pendingMaintenance = body.pendingMaintenance
                } else {
                    errorMessage = "تعذر الاتصال بالسيرفر السحابي (${res.code()})"
                }
            } catch (e: Exception) {
                errorMessage = "خطأ في الاتصال: ${e.localizedMessage ?: "تحقق من الرابط"}"
            } finally {
                isLoading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        loadData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("لوحة التحكم والمتابعة", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSurface,
                    titleContentColor = TextPrimary
                ),
                actions = {
                    IconButton(onClick = { loadData() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = TextPrimary)
                    }
                }
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        if (isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = PrimaryLightBlue)
            }
        } else if (errorMessage != null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(errorMessage!!, color = AccentRed, fontSize = 16.sp)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { loadData() }) { Text("إعادة المحاولة") }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Quick KPI Stats Grid
                item {
                    stats?.let { s ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard("إجمالي الأسطول", "${s.totalVehicles}", Icons.Default.DirectionsCar, PrimaryLightBlue, Modifier.weight(1f))
                            StatCard("في الطريق", "${s.activeVehicles}", Icons.Default.Navigation, AccentGreen, Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatCard("في الصيانة", "${s.maintenanceVehicles}", Icons.Default.Build, AccentOrange, Modifier.weight(1f))
                            StatCard("حركات اليوم", "${s.todayTrips}", Icons.Default.Schedule, PrimaryBlue, Modifier.weight(1f))
                        }
                    }
                }

                // Urgent Maintenance Section
                if (pendingMaintenance.isNotEmpty()) {
                    item {
                        Text(
                            "🚨 تنبيهات صيانة عاجلة (${pendingMaintenance.size})",
                            color = AccentRed,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    items(pendingMaintenance) { maint ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkCard),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = AccentRed)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("سيارة: ${maint.vehiclePlate}", color = TextPrimary, fontWeight = FontWeight.Bold)
                                    Text(maint.issueDescription, color = TextSecondary, fontSize = 13.sp)
                                    Text("السائق: ${maint.driverName ?: "غير محدد"}", color = TextSecondary, fontSize = 12.sp)
                                }
                                SuggestionChip(
                                    onClick = { onNavigateToVehicleDetail(maint.vehiclePlate) },
                                    label = { Text("معاينة") }
                                )
                            }
                        }
                    }
                }

                // Recent Trips
                item {
                    Text(
                        "📋 آخر الحركات المسجلة",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (recentTrips.isEmpty()) {
                    item {
                        Text("لا توجد حركات مسجلة حتى الآن.", color = TextSecondary)
                    }
                } else {
                    items(recentTrips) { trip ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("🚗 ${trip.vehiclePlate}", color = PrimaryLightBlue, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    val badgeColor = if (trip.eventType.contains("خروج")) AccentOrange else AccentGreen
                                    Text(
                                        trip.eventType,
                                        color = badgeColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                                Spacer(Modifier.height(6.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("👤 السائق: ${trip.driverName ?: "غير مسجل"}", color = TextSecondary, fontSize = 13.sp)
                                    Text("⏱️ العداد: ${trip.odometerReading?.let { "$it كم" } ?: "—"}", color = TextPrimary, fontSize = 13.sp)
                                }
                                if (!trip.destination.isNullOrBlank()) {
                                    Text("📍 الوجهة: ${trip.destination}", color = TextSecondary, fontSize = 12.sp)
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("🕒 ${trip.createdAt}", color = TextSecondary.copy(alpha = 0.6f), fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(title, color = TextSecondary, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                Text(value, color = accentColor, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(32.dp))
        }
    }
}
