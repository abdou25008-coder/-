package com.fleetai.app.ui.screens.whatsapp

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.fleetai.app.data.models.*
import com.fleetai.app.data.remote.RetrofitClient
import com.fleetai.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatsAppScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var statusData by remember { mutableStateOf<WhatsAppStatusResponse?>(null) }
    var groups by remember { mutableStateOf<List<GroupItem>>(emptyList()) }
    var serverUrlInput by remember { mutableStateOf(RetrofitClient.baseUrl) }
    var isLoading by remember { mutableStateOf(true) }

    // Dialog state for group settings
    var showSettingsDialog by remember { mutableStateOf(false) }
    var selectedGroupForSettings by remember { mutableStateOf<GroupItem?>(null) }
    var dialogIsSilent by remember { mutableStateOf(true) }
    var dialogReplyInGroup by remember { mutableStateOf(false) }
    var dialogManagerPhone by remember { mutableStateOf("") }
    var dialogNotifyOil by remember { mutableStateOf(true) }
    var dialogNotifyFuel by remember { mutableStateOf(true) }

    fun refreshData() {
        coroutineScope.launch {
            isLoading = true
            try {
                val statusRes = RetrofitClient.apiService.getWhatsAppStatus()
                if (statusRes.isSuccessful) {
                    statusData = statusRes.body()
                }
                val groupsRes = RetrofitClient.apiService.getGroups()
                if (groupsRes.isSuccessful && groupsRes.body()?.success == true) {
                    groups = groupsRes.body()!!.groups
                }
            } catch (_: Exception) {}
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        refreshData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ربط وإدارة مجموعات واتساب", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface, titleContentColor = TextPrimary),
                actions = {
                    IconButton(onClick = { refreshData() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = TextPrimary)
                    }
                }
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Server URL Configuration Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("🌐 رابط السيرفر السحابي (Cloud Backend URL):", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = serverUrlInput,
                                onValueChange = { serverUrlInput = it },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PrimaryLightBlue,
                                    unfocusedBorderColor = DividerColor,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    RetrofitClient.baseUrl = serverUrlInput
                                    refreshData()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                            ) {
                                Text("حفظ")
                            }
                        }
                    }
                }
            }

            // WhatsApp Connection State Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("حالة الاتصال بواتساب", color = TextSecondary, fontSize = 14.sp)
                        Spacer(Modifier.height(6.dp))

                        val state = statusData?.status ?: "disconnected"
                        val (badgeText, badgeColor) = when (state) {
                            "connected" -> "🟢 متصل بالسيرفر والجروبات" to AccentGreen
                            "waiting_for_qr" -> "⏳ في انتظار مسح رمز QR" to AccentOrange
                            else -> "🔴 غير متصل" to AccentRed
                        }

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = badgeColor.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor)
                        ) {
                            Text(
                                badgeText,
                                color = badgeColor,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (!statusData?.botJid.isNullOrBlank()) {
                            Spacer(Modifier.height(8.dp))
                            Text("رقم البوت: ${statusData?.botJid}", color = PrimaryLightBlue, fontSize = 14.sp)
                        }

                        // Display QR Code if waiting
                        if (state == "waiting_for_qr" && !statusData?.qrCode.isNullOrBlank()) {
                            Spacer(Modifier.height(16.dp))
                            Text("امسح الرمز التالي من واتساب (الأجهزة المرتبطة):", color = TextPrimary, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            AsyncImage(
                                model = ImageRequest.Builder(context)
                                    .data(statusData!!.qrCode)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = "QR Code",
                                modifier = Modifier
                                    .size(220.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.White)
                                    .padding(8.dp),
                                contentScale = ContentScale.Fit
                            )
                        }
                    }
                }
            }

            // Quick Activation Instructions Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = PrimaryLightBlue)
                            Spacer(Modifier.width(8.dp))
                            Text("كيفية تفعيل المساعد في أي جروب جديد:", color = PrimaryLightBlue, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("1. أضف رقم البوت كعضو في جروب واتساب الخاص بالسيارات.", color = TextSecondary, fontSize = 13.sp)
                        Text("2. اكتب في الجروب: /تفعيل أو /activate", color = TextSecondary, fontSize = 13.sp)
                        Text("3. سيبدأ النظام فوراً بقراءة وتوثيق كل أوراق الحركة وصور العدادات!", color = TextSecondary, fontSize = 13.sp)
                    }
                }
            }

            // Monitored Groups List
            item {
                Text(
                    "👥 المجموعات النشطة تحت المراقبة (${groups.size})",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            if (groups.isEmpty()) {
                item {
                    Text("لم يتم ربط أو تفعيل أي مجموعة حتى الآن.", color = TextSecondary)
                }
            } else {
                items(groups) { g ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(g.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    val modeText = if (g.isSilent == 1) "🔒 وضع صامت (مراقبة فقط دون نشر)" else "📢 نشر تفاعلي بالجروب"
                                    Text(modeText, color = if (g.isSilent == 1) AccentOrange else AccentGreen, fontSize = 12.sp)
                                }
                                Switch(
                                    checked = g.isActive == 1,
                                    onCheckedChange = { active ->
                                        coroutineScope.launch {
                                            RetrofitClient.apiService.toggleGroup(GroupToggleRequest(g.id, active))
                                            refreshData()
                                        }
                                    }
                                )
                            }

                            Spacer(Modifier.height(8.dp))
                            HorizontalDivider(color = DividerColor)
                            Spacer(Modifier.height(8.dp))

                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (!g.managerPhone.isNullOrBlank()) "هاتف المدير: ${g.managerPhone}" else "لم يُحدد هاتف للمدير",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )
                                OutlinedButton(
                                    onClick = {
                                        selectedGroupForSettings = g
                                        dialogIsSilent = g.isSilent == 1
                                        dialogReplyInGroup = g.replyInGroup == 1
                                        dialogManagerPhone = g.managerPhone ?: ""
                                        dialogNotifyOil = g.notifyOilAlerts == 1
                                        dialogNotifyFuel = g.notifyFuelAlerts == 1
                                        showSettingsDialog = true
                                    },
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("خصائص النشر والتنبيهات", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Group Settings & Privacy Dialog
    if (showSettingsDialog && selectedGroupForSettings != null) {
        val g = selectedGroupForSettings!!
        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text("إعدادات مراقبة: ${g.name}", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    // Silent Mode Toggle
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("الوضع الصامت للمراقبة", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("عدم كتابة أي ردود أو رسائل في الجروب نهائياً", color = TextSecondary, fontSize = 11.sp)
                        }
                        Switch(checked = dialogIsSilent, onCheckedChange = { dialogIsSilent = it })
                    }

                    Spacer(Modifier.height(10.dp))

                    // Reply in Group Toggle
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("السماح بالردود بالجروب", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("الرد بتأكيد تسجيل العداد في الشات العام", color = TextSecondary, fontSize = 11.sp)
                        }
                        Switch(checked = dialogReplyInGroup, onCheckedChange = { dialogReplyInGroup = it })
                    }

                    Spacer(Modifier.height(12.dp))

                    // Manager WhatsApp Phone
                    Text("رقم واتساب المدير لاستلام التنبيهات الخاصة:", color = TextPrimary, fontSize = 13.sp)
                    Spacer(Modifier.height(4.dp))
                    OutlinedTextField(
                        value = dialogManagerPhone,
                        onValueChange = { dialogManagerPhone = it },
                        placeholder = { Text("مثال: 201012345678", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Spacer(Modifier.height(10.dp))

                    // Oil Alerts to Manager
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إرسال تنبيهات الزيوت للمدير على الخاص", color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Switch(checked = dialogNotifyOil, onCheckedChange = { dialogNotifyOil = it })
                    }

                    Spacer(Modifier.height(6.dp))

                    // Fuel Alerts to Manager
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("إرسال تنبيهات استهلاك الوقود المرتفع", color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        Switch(checked = dialogNotifyFuel, onCheckedChange = { dialogNotifyFuel = it })
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                RetrofitClient.apiService.updateGroupSettings(
                                    GroupSettingsRequest(
                                        groupId = g.id,
                                        isSilent = dialogIsSilent,
                                        replyInGroup = dialogReplyInGroup,
                                        managerPhone = dialogManagerPhone.trim(),
                                        notifyOilAlerts = dialogNotifyOil,
                                        notifyFuelAlerts = dialogNotifyFuel
                                    )
                                )
                                Toast.makeText(context, "تم حفظ الإعدادات بنجاح!", Toast.LENGTH_SHORT).show()
                                showSettingsDialog = false
                                refreshData()
                            } catch (e: Exception) {
                                Toast.makeText(context, "خطأ: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                ) {
                    Text("حفظ التغييرات")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSettingsDialog = false }) { Text("إلغاء") }
            }
        )
    }
}
