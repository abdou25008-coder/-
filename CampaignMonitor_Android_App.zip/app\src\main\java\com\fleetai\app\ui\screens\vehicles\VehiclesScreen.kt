package com.fleetai.app.ui.screens.vehicles

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fleetai.app.data.models.Vehicle
import com.fleetai.app.data.remote.RetrofitClient
import com.fleetai.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VehiclesScreen(
    onNavigateToDetail: (String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var vehicles by remember { mutableStateOf<List<Vehicle>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }

    fun loadVehicles() {
        coroutineScope.launch {
            isLoading = true
            try {
                val res = RetrofitClient.apiService.getVehicles()
                if (res.isSuccessful && res.body()?.success == true) {
                    vehicles = res.body()!!.vehicles
                }
            } catch (_: Exception) {}
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        loadVehicles()
    }

    val filtered = vehicles.filter {
        it.plateNumber.contains(searchQuery.trim(), ignoreCase = true) ||
        (it.lastDriver?.contains(searchQuery.trim(), ignoreCase = true) == true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("دليل وسجلات السيارات", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface, titleContentColor = TextPrimary),
                actions = {
                    IconButton(onClick = { loadVehicles() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = TextPrimary)
                    }
                }
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Search Box
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ابحث برقم اللوحة أو اسم السائق...", color = TextSecondary) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryLightBlue,
                    unfocusedBorderColor = DividerColor,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(Modifier.height(16.dp))

            if (isLoading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryLightBlue)
                }
            } else if (filtered.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا توجد سيارات مطابقة للبحث.", color = TextSecondary)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(filtered) { v ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToDetail(v.plateNumber) }
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("🚗 ${v.plateNumber}", color = PrimaryLightBlue, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                    val statusColor = when (v.status) {
                                        "في الطريق" -> AccentGreen
                                        "في الصيانة" -> AccentOrange
                                        else -> PrimaryBlue
                                    }
                                    Badge(containerColor = statusColor) {
                                        Text(v.status, color = TextPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                    }
                                }

                                Spacer(Modifier.height(8.dp))
                                HorizontalDivider(color = DividerColor)
                                Spacer(Modifier.height(8.dp))

                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("⏱️ العداد الحالي: ${v.currentKm.toLocaleString()} كم", color = TextPrimary, fontSize = 14.sp)
                                    Text("👤 السائق: ${v.lastDriver ?: "غير مسجل"}", color = TextSecondary, fontSize = 14.sp)
                                }

                                if (!v.lastTripTime.isNullOrBlank()) {
                                    Spacer(Modifier.height(4.dp))
                                    Text("🕒 آخر نشاط: ${v.lastTripTime}", color = TextSecondary.copy(alpha = 0.6f), fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun Long.toLocaleString(): String {
    return String.format("%,d", this)
}
