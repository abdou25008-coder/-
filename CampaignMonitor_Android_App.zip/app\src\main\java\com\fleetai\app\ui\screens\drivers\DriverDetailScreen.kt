package com.fleetai.app.ui.screens.drivers

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fleetai.app.data.models.*
import com.fleetai.app.data.remote.RetrofitClient
import com.fleetai.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DriverDetailScreen(
    driverName: String,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var activityData by remember { mutableStateOf<DriverMonthlyActivity?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var isSendingReport by remember { mutableStateOf(false) }

    fun loadDriverActivity() {
        coroutineScope.launch {
            isLoading = true
            try {
                val res = RetrofitClient.apiService.getDriverMonthlyActivity(driverName)
                if (res.isSuccessful && res.body()?.success == true) {
                    activityData = res.body()!!.activity
                }
            } catch (_: Exception) {}
            isLoading = false
        }
    }

    LaunchedEffect(driverName) {
        loadDriverActivity()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ملف السائق وشؤون العاملين", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface, titleContentColor = TextPrimary),
                actions = {
                    IconButton(onClick = { loadDriverActivity() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = TextPrimary)
                    }
                }
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        if (isLoading) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = PrimaryLightBlue)
            }
        } else if (activityData == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("لم يتم العثور على سجلات للسائق: $driverName", color = TextSecondary)
            }
        } else {
            val driver = activityData!!.driver
            val dailyLogs = activityData!!.dailyLogs

            LazyColumn(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Driver Profile Snapshot
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkSurface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(driver.name, color = PrimaryLightBlue, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                    Text("سجل متابعة الموارد البشرية", color = TextSecondary, fontSize = 12.sp)
                                }
                                Badge(containerColor = if (driver.activeToday == 1) AccentGreen else DarkCard) {
                                    Text(
                                        if (driver.activeToday == 1) "يعمل اليوم" else "غير مسجل اليوم",
                                        color = TextPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(Modifier.height(14.dp))
                            HorizontalDivider(color = DividerColor)
                            Spacer(Modifier.height(14.dp))

                            // HR Monthly Metrics Grid
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("أيام العمل شهرياً", color = TextSecondary, fontSize = 11.sp)
                                        Spacer(Modifier.height(4.dp))
                                        Text("${activityData!!.workingDaysCount} يوم", color = PrimaryLightBlue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("السيارة الحالية", color = TextSecondary, fontSize = 11.sp)
                                        Spacer(Modifier.height(4.dp))
                                        Text(driver.currentVehicle ?: "غير محدد", color = AccentGreen, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(Modifier.height(12.dp))

                            // Send HR Report via WhatsApp Button
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        isSendingReport = true
                                        try {
                                            val reportRes = RetrofitClient.apiService.generateReport(
                                                ReportRequest(type = "driver", target = driver.name)
                                            )
                                            if (reportRes.isSuccessful && reportRes.body()?.success == true) {
                                                val text = reportRes.body()!!.report
                                                val sendRes = RetrofitClient.apiService.sendReportViaWhatsApp(
                                                    SendWhatsAppRequest(
                                                        recipientJid = if (!driver.phone.isNullOrBlank()) "${driver.phone}@s.whatsapp.net" else "",
                                                        reportText = text
                                                    )
                                                )
                                                Toast.makeText(context, "تم إرسال تقرير الموارد البشرية!", Toast.LENGTH_SHORT).show()
                                            }
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "خطأ: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                        } finally {
                                            isSendingReport = false
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("إرسال تقرير الحضور الشهري لـ واتساب")
                            }
                        }
                    }
                }

                // Daily Work Breakdown Title
                item {
                    Text(
                        "🗓️ تفاصيل أيام وساعات العمل اليومية (${dailyLogs.size} يوم مسجل)",
                        color = TextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (dailyLogs.isEmpty()) {
                    item {
                        Text("لا يوجد نشاط عمل مسجل لهذا الشهر.", color = TextSecondary)
                    }
                } else {
                    items(dailyLogs) { log ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("📅 ${log.workDate}", color = PrimaryLightBlue, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Badge(containerColor = PrimaryBlue.copy(alpha = 0.3f)) {
                                        Text("${log.tripsCount} رحلات/حركات", color = TextPrimary, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }

                                Spacer(Modifier.height(8.dp))
                                Text("🚗 السيارات المستخدمة: ${log.vehiclesUsed ?: "غير مسجل"}", color = TextPrimary, fontSize = 13.sp)
                                Spacer(Modifier.height(4.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("⏰ أول نشاط: ${log.firstActivityTime}", color = TextSecondary, fontSize = 12.sp)
                                    Text("⏰ آخر نشاط: ${log.lastActivityTime}", color = TextSecondary, fontSize = 12.sp)
                                }

                                if (log.minKm != null && log.maxKm != null && log.maxKm > log.minKm) {
                                    val dist = log.maxKm - log.minKm
                                    Spacer(Modifier.height(4.dp))
                                    Text("🛣️ إجمالي المسافة المقطوعة اليوم: $dist كم", color = AccentGreen, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
