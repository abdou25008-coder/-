package com.fleetai.app.data.models

import com.google.gson.annotations.SerializedName

data class Vehicle(
    @SerializedName("plate_number") val plateNumber: String,
    @SerializedName("model") val model: String?,
    @SerializedName("current_km") val currentKm: Long,
    @SerializedName("status") val status: String, // "متاح", "في الطريق", "في الصيانة"
    @SerializedName("last_driver") val lastDriver: String?,
    @SerializedName("last_trip_time") val lastTripTime: String?,
    @SerializedName("notes") val notes: String?
)

data class Driver(
    @SerializedName("name") val name: String,
    @SerializedName("phone") val phone: String?,
    @SerializedName("total_trips") val totalTrips: Int,
    @SerializedName("total_km") val totalKm: Long,
    @SerializedName("current_vehicle") val currentVehicle: String?,
    @SerializedName("last_active") val lastActive: String?,
    @SerializedName("working_days_this_month") val workingDaysThisMonth: Int = 0,
    @SerializedName("trips_this_month") val tripsThisMonth: Int = 0,
    @SerializedName("active_today") val activeToday: Int = 0
)

data class DailyWorkLog(
    @SerializedName("work_date") val workDate: String,
    @SerializedName("trips_count") val tripsCount: Int,
    @SerializedName("first_activity_time") val firstActivityTime: String,
    @SerializedName("last_activity_time") val lastActivityTime: String,
    @SerializedName("min_km") val minKm: Long?,
    @SerializedName("max_km") val maxKm: Long?,
    @SerializedName("vehicles_used") val vehiclesUsed: String?
)

data class DriverMonthlyActivity(
    @SerializedName("driver") val driver: Driver,
    @SerializedName("month") val month: String,
    @SerializedName("workingDaysCount") val workingDaysCount: Int,
    @SerializedName("dailyLogs") val dailyLogs: List<DailyWorkLog>,
    @SerializedName("trips") val trips: List<Trip>
)

data class DriverMonthlyResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("activity") val activity: DriverMonthlyActivity
)

data class Trip(
    @SerializedName("id") val id: Long,
    @SerializedName("group_id") val groupId: String?,
    @SerializedName("vehicle_plate") val vehiclePlate: String,
    @SerializedName("driver_name") val driverName: String?,
    @SerializedName("event_type") val eventType: String, // "خروج", "عودة", "حركة"
    @SerializedName("odometer_reading") val odometerReading: Long?,
    @SerializedName("destination") val destination: String?,
    @SerializedName("notes") val notes: String?,
    @SerializedName("raw_text") val rawText: String?,
    @SerializedName("image_path") val imagePath: String?,
    @SerializedName("confidence") val confidence: Float,
    @SerializedName("created_at") val createdAt: String
)

data class MaintenanceLog(
    @SerializedName("id") val id: Long,
    @SerializedName("vehicle_plate") val vehiclePlate: String,
    @SerializedName("driver_name") val driverName: String?,
    @SerializedName("issue_description") val issueDescription: String,
    @SerializedName("severity") val severity: String, // "منخفض", "عادي", "عاجل"
    @SerializedName("status") val status: String, // "قيد الانتظار", "تم الإصلاح"
    @SerializedName("image_path") val imagePath: String?,
    @SerializedName("reported_at") val reportedAt: String
)

data class GroupItem(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("is_active") val isActive: Int,
    @SerializedName("is_silent") val isSilent: Int = 1,
    @SerializedName("reply_in_group") val replyInGroup: Int = 0,
    @SerializedName("manager_phone") val managerPhone: String? = null,
    @SerializedName("notify_oil_alerts") val notifyOilAlerts: Int = 1,
    @SerializedName("notify_fuel_alerts") val notifyFuelAlerts: Int = 1
)

data class GroupSettingsRequest(
    @SerializedName("groupId") val groupId: String,
    @SerializedName("isSilent") val isSilent: Boolean,
    @SerializedName("replyInGroup") val replyInGroup: Boolean,
    @SerializedName("managerPhone") val managerPhone: String,
    @SerializedName("notifyOilAlerts") val notifyOilAlerts: Boolean,
    @SerializedName("notifyFuelAlerts") val notifyFuelAlerts: Boolean
)

data class FuelLog(
    @SerializedName("id") val id: Long,
    @SerializedName("vehicle_plate") val vehiclePlate: String,
    @SerializedName("driver_name") val driverName: String?,
    @SerializedName("liters") val liters: Float,
    @SerializedName("cost") val cost: Float,
    @SerializedName("odometer_reading") val odometerReading: Long?,
    @SerializedName("distance_traveled") val distanceTraveled: Float,
    @SerializedName("fuel_rate") val fuelRate: Float,
    @SerializedName("is_abnormal") val isAbnormal: Int,
    @SerializedName("notes") val notes: String?,
    @SerializedName("created_at") val createdAt: String
)

data class FuelAnalyticsSummary(
    @SerializedName("totalFillups") val totalFillups: Int,
    @SerializedName("totalLiters") val totalLiters: Int,
    @SerializedName("totalCost") val totalCost: Int,
    @SerializedName("avgKmPerLiter") val avgKmPerLiter: Float,
    @SerializedName("abnormalIncidents") val abnormalIncidents: Int
)

data class FuelAnalyticsData(
    @SerializedName("summary") val summary: FuelAnalyticsSummary,
    @SerializedName("recentLogs") val recentLogs: List<FuelLog>,
    @SerializedName("abnormalLogs") val abnormalLogs: List<FuelLog>
)

data class FuelAnalyticsResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("data") val data: FuelAnalyticsData
)

data class OilRadarItem(
    @SerializedName("plateNumber") val plateNumber: String,
    @SerializedName("model") val model: String?,
    @SerializedName("lastDriver") val lastDriver: String?,
    @SerializedName("currentKm") val currentKm: Long,
    @SerializedName("lastOilKm") val lastOilKm: Long,
    @SerializedName("oilIntervalKm") val oilIntervalKm: Long,
    @SerializedName("nextDueKm") val nextDueKm: Long,
    @SerializedName("remainingKm") val remainingKm: Long,
    @SerializedName("urgency") val urgency: String, // "danger", "warning", "safe"
    @SerializedName("statusText") val statusText: String
)

data class OilRadarResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("radar") val radar: List<OilRadarItem>
)

data class RecordOilChangeRequest(
    @SerializedName("plate") val plate: String,
    @SerializedName("currentKm") val currentKm: Long? = null,
    @SerializedName("intervalKm") val intervalKm: Long? = null
)

data class DashboardStats(
    @SerializedName("totalVehicles") val totalVehicles: Int,
    @SerializedName("activeVehicles") val activeVehicles: Int,
    @SerializedName("maintenanceVehicles") val maintenanceVehicles: Int,
    @SerializedName("todayTrips") val todayTrips: Int,
    @SerializedName("pendingMaintenance") val pendingMaintenance: Int
)

data class DashboardResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("stats") val stats: DashboardStats,
    @SerializedName("recentTrips") val recentTrips: List<Trip>,
    @SerializedName("pendingMaintenance") val pendingMaintenance: List<MaintenanceLog>
)

data class VehiclesResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("vehicles") val vehicles: List<Vehicle>
)

data class VehicleDetailResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("vehicle") val vehicle: Vehicle,
    @SerializedName("trips") val trips: List<Trip>,
    @SerializedName("maintenance") val maintenance: List<MaintenanceLog>
)

data class DriversResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("drivers") val drivers: List<Driver>
)

data class WhatsAppStatusResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("status") val status: String, // "connected", "waiting_for_qr", "disconnected"
    @SerializedName("botJid") val botJid: String?,
    @SerializedName("botName") val botName: String?,
    @SerializedName("qrCode") val qrCode: String?
)

data class GroupsResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("groups") val groups: List<GroupItem>
)

data class GroupToggleRequest(
    @SerializedName("groupId") val groupId: String,
    @SerializedName("active") val active: Boolean
)

data class ReportRequest(
    @SerializedName("type") val type: String, // "vehicle", "driver", "daily"
    @SerializedName("target") val target: String?
)

data class ReportResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("report") val report: String
)

data class SendWhatsAppRequest(
    @SerializedName("recipientJid") val recipientJid: String,
    @SerializedName("reportText") val reportText: String
)

data class SimpleResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("message") val message: String?
)
