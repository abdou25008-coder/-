package com.fleetai.app.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkCard = Color(0xFF27354A)

val PrimaryBlue = Color(0xFF0284C7)
val PrimaryLightBlue = Color(0xFF38BDF8)
val AccentGreen = Color(0xFF10B981)
val AccentOrange = Color(0xFFF59E0B)
val AccentRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val DividerColor = Color(0xFF334155)
