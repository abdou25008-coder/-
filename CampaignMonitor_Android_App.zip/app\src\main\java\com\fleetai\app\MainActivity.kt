package com.fleetai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.fleetai.app.ui.navigation.AppNavigation
import com.fleetai.app.ui.theme.FleetAITheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FleetAITheme {
                AppNavigation()
            }
        }
    }
}
