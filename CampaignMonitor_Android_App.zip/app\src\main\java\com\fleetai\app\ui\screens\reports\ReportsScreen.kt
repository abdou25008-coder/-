package com.fleetai.app.ui.screens.reports

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fleetai.app.data.models.*
import com.fleetai.app.data.remote.RetrofitClient
import com.fleetai.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var reportType by remember { mutableStateOf("daily") } // "daily", "vehicle", "driver"
    var targetInput by remember { mutableStateOf("") }
    var generatedReport by remember { mutableStateOf<String?>(null) }
    var recipientJid by remember { mutableStateOf("") }
    var isGenerating by remember { mutableStateOf(false) }
    var isSendingWhatsApp by remember { mutableStateOf(false) }
    var showSendDialog by remember { mutableStateOf(false) }

    fun generate() {
        coroutineScope.launch {
            isGenerating = true
            try {
                val res = RetrofitClient.apiService.generateReport(
                    ReportRequest(type = reportType, target = targetInput.trim())
                )
                if (res.isSuccessful && res.body()?.success == true) {
                    generatedReport = res.body()!!.report
                } else {
                    Toast.makeText(context, "فشل إنشاء التقرير", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "خطأ: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            } finally {
                isGenerating = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مركز التقارير والإرسال", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkSurface, titleContentColor = TextPrimary)
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        LazyColumn(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Report Configuration Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("اختر نوع التقرير المطلوب:", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = reportType == "daily",
                                onClick = { reportType = "daily" },
                                label = { Text("يومي عام") }
                            )
                            FilterChip(
                                selected = reportType == "vehicle",
                                onClick = { reportType = "vehicle" },
                                label = { Text("سجل سيارة") }
                            )
                            FilterChip(
                                selected = reportType == "driver",
                                onClick = { reportType = "driver" },
                                label = { Text("سائق (HR)") }
                            )
                            FilterChip(
                                selected = reportType == "hr_monthly",
                                onClick = { reportType = "hr_monthly" },
                                label = { Text("كشف HR شامل") }
                            )
                        }

                        if (reportType == "vehicle" || reportType == "driver") {
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(
                                value = targetInput,
                                onValueChange = { targetInput = it },
                                placeholder = {
                                    Text(if (reportType == "vehicle") "أدخل رقم لوحة السيارة (مثال: 4589)" else "أدخل اسم السائق...")
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PrimaryLightBlue,
                                    unfocusedBorderColor = DividerColor,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )
                        }

                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { generate() },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !isGenerating,
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
                        ) {
                            if (isGenerating) {
                                CircularProgressIndicator(color = TextPrimary, modifier = Modifier.size(20.dp))
                            } else {
                                Icon(Icons.Default.Assessment, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("توليد التقرير الآن")
                            }
                        }
                    }
                }
            }

            // Generated Report Display Card
            if (generatedReport != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = DarkCard),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("معاينة التقرير النهائي", color = PrimaryLightBlue, fontWeight = FontWeight.Bold)
                                Row {
                                    IconButton(onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("Fleet Report", generatedReport)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "تم نسخ التقرير", Toast.LENGTH_SHORT).show()
                                    }) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", tint = TextPrimary)
                                    }
                                    IconButton(onClick = { showSendDialog = true }) {
                                        Icon(Icons.Default.Share, contentDescription = "إرسال لواتساب", tint = AccentGreen)
                                    }
                                }
                            }

                            HorizontalDivider(color = DividerColor, modifier = Modifier.padding(vertical = 8.dp))

                            Text(
                                text = generatedReport!!,
                                color = TextPrimary,
                                fontSize = 14.sp,
                                lineHeight = 22.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // WhatsApp Direct Send Dialog
    if (showSendDialog) {
        AlertDialog(
            onDismissRequest = { showSendDialog = false },
            title = { Text("إرسال التقرير عبر واتساب") },
            text = {
                Column {
                    Text("أدخل رقم الهاتف مع كود الدولة أو معرف الجروب:")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = recipientJid,
                        onValueChange = { recipientJid = it },
                        placeholder = { Text("مثال: 201012345678 أو معرف الجروب") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isSendingWhatsApp = true
                            try {
                                var targetJid = recipientJid.trim()
                                if (!targetJid.contains("@")) {
                                    targetJid = "$targetJid@s.whatsapp.net"
                                }
                                val res = RetrofitClient.apiService.sendReportViaWhatsApp(
                                    SendWhatsAppRequest(targetJid, generatedReport ?: "")
                                )
                                if (res.isSuccessful && res.body()?.success == true) {
                                    Toast.makeText(context, "تم إرسال التقرير بنجاح عبر واتساب!", Toast.LENGTH_LONG).show()
                                    showSendDialog = false
                                } else {
                                    Toast.makeText(context, "فشل الإرسال عبر واتساب", Toast.LENGTH_SHORT).show()
                                }
                            } catch (e: Exception) {
                                Toast.makeText(context, "خطأ: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                            } finally {
                                isSendingWhatsApp = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentGreen)
                ) {
                    Text("إرسال الآن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSendDialog = false }) { Text("إلغاء") }
            }
        )
    }
}
