package com.fleetai.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.fleetai.app.ui.screens.dashboard.DashboardScreen
import com.fleetai.app.ui.screens.drivers.DriversScreen
import com.fleetai.app.ui.screens.reports.ReportsScreen
import com.fleetai.app.ui.screens.vehicles.VehicleDetailScreen
import com.fleetai.app.ui.screens.vehicles.VehiclesScreen
import com.fleetai.app.ui.screens.whatsapp.WhatsAppScreen
import com.fleetai.app.ui.theme.*

data class BottomNavItem(
    val route: String,
    val title: String,
    val icon: ImageVector
)

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val navItems = listOf(
        BottomNavItem(Screen.Dashboard.route, "الرئيسية", Icons.Default.Dashboard),
        BottomNavItem(Screen.Vehicles.route, "السيارات", Icons.Default.DirectionsCar),
        BottomNavItem(Screen.FuelAndOil.route, "الوقود والزيوت", Icons.Default.LocalGasStation),
        BottomNavItem(Screen.Drivers.route, "السائقين", Icons.Default.People),
        BottomNavItem(Screen.WhatsApp.route, "واتساب", Icons.Default.Chat),
        BottomNavItem(Screen.Reports.route, "التقارير", Icons.Default.Assessment)
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                contentColor = TextPrimary
            ) {
                navItems.forEach { item ->
                    val selected = currentDestination?.route == item.route
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.title) },
                        label = { Text(item.title) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PrimaryLightBlue,
                            selectedTextColor = PrimaryLightBlue,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary,
                            indicatorColor = DarkCard
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Dashboard.route) {
                DashboardScreen(
                    onNavigateToVehicleDetail = { plate ->
                        navController.navigate(Screen.VehicleDetail.createRoute(plate))
                    }
                )
            }

            composable(Screen.Vehicles.route) {
                VehiclesScreen(
                    onNavigateToDetail = { plate ->
                        navController.navigate(Screen.VehicleDetail.createRoute(plate))
                    }
                )
            }

            composable(Screen.FuelAndOil.route) {
                com.fleetai.app.ui.screens.fuel.FuelAndOilScreen()
            }

            composable(
                route = Screen.VehicleDetail.route,
                arguments = listOf(navArgument("plate") { type = NavType.StringType })
            ) { backStackEntry ->
                val plate = backStackEntry.arguments?.getString("plate") ?: ""
                VehicleDetailScreen(
                    plateNumber = plate,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Drivers.route) {
                DriversScreen(
                    onNavigateToDriverDetail = { name ->
                        navController.navigate(Screen.DriverDetail.createRoute(name))
                    }
                )
            }

            composable(
                route = Screen.DriverDetail.route,
                arguments = listOf(navArgument("name") { type = NavType.StringType })
            ) { backStackEntry ->
                val name = backStackEntry.arguments?.getString("name") ?: ""
                com.fleetai.app.ui.screens.drivers.DriverDetailScreen(
                    driverName = name,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.WhatsApp.route) {
                WhatsAppScreen()
            }

            composable(Screen.Reports.route) {
                ReportsScreen()
            }
        }
    }
}
