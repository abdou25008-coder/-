package com.fleetai.app.data.remote

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    // Default cloud server URL (Can be changed in app settings or dynamically)
    var baseUrl: String = "http://10.0.2.2:3000/" // Default for Android Emulator to local, or replace with your Cloud URL
        set(value) {
            field = if (value.endsWith("/")) value else "$value/"
            apiService = createService(field)
        }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        })
        .build()

    private fun createService(url: String): FleetApiService {
        return Retrofit.Builder()
            .baseUrl(url)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(FleetApiService::class.java)
    }

    var apiService: FleetApiService = createService(baseUrl)
        private set
}
